﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Text;

namespace PizzeriaBellaItalia
{
    internal class PedidoPizza
    {
        // Propiedades auto-implementadas de Entidad ({ get; set; })
        public string Cliente { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public string Tamano { get; set; } = "Mediana";
        public string TipoMasa { get; set; } = "Tradicional";

        // Adicionales
        public bool QuesoExtra { get; set; }
        public bool Pepperoni { get; set; }
        public bool Champinones { get; set; }
        public bool Aceitunas { get; set; }
        public bool Tocino { get; set; }

        // Opciones de Entrega y Beneficio
        public bool EsDelivery { get; set; }
        public bool AplicaConvenioEstudiante { get; set; }

        // Constantes de Precios de Negocio
        private const double PRECIO_PERSONAL = 5000.0;
        private const double PRECIO_MEDIANA = 8500.0;
        private const double PRECIO_FAMILIAR = 12000.0;
        private const double PRECIO_BORDE_QUESO = 1500.0;
        private const double PRECIO_INGREDIENTE_EXTRA = 800.0;
        private const double RECARGO_DELIVERY = 2000.0;
        private const double TASA_DESCUENTO = 0.10; // 10%
        private const double TASA_IVA = 0.19; // 19%

        // MÉTODOS PUROS DE CÁLCULO DE NEGOCIO (SRP)
        public double CalcularPrecioTamano()
        {
            if (Tamano.Contains("Personal", StringComparison.OrdinalIgnoreCase))
                return PRECIO_PERSONAL;
            else if (Tamano.Contains("Familiar", StringComparison.OrdinalIgnoreCase))
                return PRECIO_FAMILIAR;
            else
                return PRECIO_MEDIANA; // Por defecto o Mediana
        }

        public double CalcularCostoMasa()
        {
            if (string.IsNullOrWhiteSpace(TipoMasa))
                return 0.0;

            // Aceptar variantes como "Borde de Queso" o "Borde de Queso (+$1.500)"
            if (TipoMasa.IndexOf("borde", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return PRECIO_BORDE_QUESO;
            }

            // Tradicional y Delgada no tienen costo adicional
            return 0.0;
        }
        public int ContarIngredientesExtra()
        {
            int contador = 0;
            if (QuesoExtra) contador++;
            if (Pepperoni) contador++;
            if (Champinones) contador++;
            if (Aceitunas) contador++;
            if (Tocino) contador++;
            return contador;
        }

        public double CalcularCostoIngredientes()
        {
            return ContarIngredientesExtra() * PRECIO_INGREDIENTE_EXTRA;
        }

        public double CalcularSubtotalPizza()
        {
            return CalcularPrecioTamano() + CalcularCostoMasa() + CalcularCostoIngredientes();
        }

        public double CalcularMontoDescuento()
        {
            if (AplicaConvenioEstudiante)
            {
                return CalcularSubtotalPizza() * TASA_DESCUENTO;
            }
            return 0.0;
        }

        public double CalcularCostoDelivery()
        {
            if (EsDelivery)
            {
                return RECARGO_DELIVERY;
            }
            return 0.0;
        }
        public double CalcularNetoAfecto()
        {
            return (CalcularSubtotalPizza() - CalcularMontoDescuento()) + CalcularCostoDelivery();
        }

        public double CalcularMontoIva()
        {
            return ((CalcularSubtotalPizza() - CalcularMontoDescuento()) + CalcularCostoDelivery()) * TASA_IVA;
        }

        public double CalcularTotalPagar()
        {
            double subtotalDescuento = CalcularSubtotalPizza() - CalcularMontoDescuento();
            double delivery = CalcularCostoDelivery();
            double neto = subtotalDescuento + delivery;
            double iva = neto * TASA_IVA;
            return neto + iva;
        }
    }
}
