using System.Globalization;

namespace PizzeriaBellaItalia
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmbTamanio_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Estandarización regional de decimales
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

            // Poblar ComboBoxes de forma dinámica
            cboTamano.Items.Clear();
            cboTamano.Items.Add("Personal ($5.000)");
            cboTamano.Items.Add("Mediana ($8.500)");
            cboTamano.Items.Add("Familiar ($12.000)");
            cboTamano.SelectedIndex = 1; // Mediana por defecto

            cboMasa.Items.Clear();
            cboMasa.Items.Add("Tradicional");
            cboMasa.Items.Add("Delgada");
            cboMasa.Items.Add("Borde de Queso (+$1.500)");
            cboMasa.SelectedIndex = 0; // Tradicional por defecto

            rdbRetiro.Checked = true;
            LimpiarResumen();

        }

        private void txtFonoCliente_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiaCampos();
        }

        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {
            LimpiarResumen();
            limpiaCampos();
            txtCliente.Focus();
        }
        private void limpiaCampos()
        {
            txtCliente.Clear();
            txtTelefono.Clear();
            cboTamano.SelectedIndex = 1;
            cboMasa.SelectedIndex = 0;
            chkQuesoExtra.Checked = false;
            chkPepperoni.Checked = false;
            chkChampinones.Checked = false;
            chkAceitunas.Checked = false;
            chkTocino.Checked = false;
            rdbRetiro.Checked = true;
            chkConvenioEstudiante.Checked = false;
        }
        private void LimpiarResumen()
        {
            lblSubtotalValor.Text = "$ 0 CLP";
            lblDescuentoValor.Text = "$ 0 CLP";
            lblDeliveryValor.Text = "$ 0 CLP";
            lblIvaValor.Text = "$ 0 CLP";
            lblTotalValor.Text = "$ 0 CLP";
            btnSalir.Enabled = false;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // Validación de entradas obligatorias
            if (string.IsNullOrWhiteSpace(txtCliente.Text))
            {
                MessageBox.Show("Por favor, ingrese el nombre del cliente.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCliente.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("Por favor, ingrese un número telefónico de contacto.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTelefono.Focus();
                return;
            }
            // Instanciación del objeto de Dominio
            PedidoPizza pedido = new PedidoPizza()
            {
                Cliente = txtCliente.Text.Trim(),
                Telefono = txtTelefono.Text.Trim(),
                Tamano = cboTamano.SelectedItem != null ? cboTamano.SelectedItem.ToString() : "Mediana",
                TipoMasa = cboMasa.SelectedItem != null ? cboMasa.SelectedItem.ToString() : "Tradicional",
                QuesoExtra = chkQuesoExtra.Checked,
                Pepperoni = chkPepperoni.Checked,
                Champinones = chkChampinones.Checked,
                Aceitunas = chkAceitunas.Checked,
                Tocino = chkTocino.Checked,
                EsDelivery = rdbDelivery.Checked,
                AplicaConvenioEstudiante = chkConvenioEstudiante.Checked
            };

            // Obtener cálculos desde la clase de Dominio
            double subtotal = pedido.CalcularSubtotalPizza();
            double descuento = pedido.CalcularMontoDescuento();
            double delivery = pedido.CalcularCostoDelivery();
            double iva = pedido.CalcularMontoIva();
            double total = pedido.CalcularTotalPagar();

            // Renderizar resultados financieros formateados en CLP
            lblSubtotalValor.Text = $"$ {subtotal:N0} CLP";
            lblDescuentoValor.Text = $"- $ {descuento:N0} CLP";
            lblDeliveryValor.Text = $"+ $ {delivery:N0} CLP";
            lblIvaValor.Text = $"+ $ {iva:N0} CLP";
            lblTotalValor.Text = $"$ {total:N0} CLP";

            //CONFIRMACION 
            DialogResult dr = MessageBox.Show(
                $"¿Desea registrar y enviar el pedido de {txtCliente.Text.Trim()} por un total de {lblTotalValor.Text}?",
                "Confirmación de Pedido",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (dr == DialogResult.Yes)
            {
                MessageBox.Show("¡Pedido registrado exitosamente! Se ha enviado a la cocina.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnLimpiar_Click(sender, e);
                btnSalir.Enabled = true;
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
