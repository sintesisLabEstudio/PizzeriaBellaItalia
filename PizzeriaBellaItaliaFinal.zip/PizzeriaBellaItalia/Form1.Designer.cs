﻿namespace PizzeriaBellaItalia
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCliente = new TextBox();
            grpDatosCliente = new GroupBox();
            lblFonoCli = new Label();
            lblNombreCli = new Label();
            txtTelefono = new TextBox();
            grpTamanioMasa = new GroupBox();
            label2 = new Label();
            label1 = new Label();
            cboMasa = new ComboBox();
            cboTamano = new ComboBox();
            grpAdicionales = new GroupBox();
            chkTocino = new CheckBox();
            chkAceitunas = new CheckBox();
            chkChampinones = new CheckBox();
            chkPepperoni = new CheckBox();
            chkQuesoExtra = new CheckBox();
            grpServicioDesc = new GroupBox();
            chkConvenioEstudiante = new CheckBox();
            rdbDelivery = new RadioButton();
            rdbRetiro = new RadioButton();
            groupBox1 = new GroupBox();
            lblTotalValor = new Label();
            lblIvaValor = new Label();
            lblDeliveryValor = new Label();
            lblDescuentoValor = new Label();
            lblSubtotalValor = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            btnCalcular = new Button();
            btnLimpiar = new Button();
            btnSalir = new Button();
            grpDatosCliente.SuspendLayout();
            grpTamanioMasa.SuspendLayout();
            grpAdicionales.SuspendLayout();
            grpServicioDesc.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtCliente
            // 
            txtCliente.Location = new Point(28, 53);
            txtCliente.Name = "txtCliente";
            txtCliente.Size = new Size(100, 23);
            txtCliente.TabIndex = 0;
            // 
            // grpDatosCliente
            // 
            grpDatosCliente.Controls.Add(lblFonoCli);
            grpDatosCliente.Controls.Add(lblNombreCli);
            grpDatosCliente.Controls.Add(txtTelefono);
            grpDatosCliente.Controls.Add(txtCliente);
            grpDatosCliente.Location = new Point(35, 22);
            grpDatosCliente.Name = "grpDatosCliente";
            grpDatosCliente.Size = new Size(278, 106);
            grpDatosCliente.TabIndex = 1;
            grpDatosCliente.TabStop = false;
            grpDatosCliente.Text = "Datos del cliente";
            // 
            // lblFonoCli
            // 
            lblFonoCli.AutoSize = true;
            lblFonoCli.Location = new Point(160, 29);
            lblFonoCli.Name = "lblFonoCli";
            lblFonoCli.Size = new Size(55, 15);
            lblFonoCli.TabIndex = 3;
            lblFonoCli.Text = "Telefono:";
            // 
            // lblNombreCli
            // 
            lblNombreCli.AutoSize = true;
            lblNombreCli.Location = new Point(51, 29);
            lblNombreCli.Name = "lblNombreCli";
            lblNombreCli.Size = new Size(54, 15);
            lblNombreCli.TabIndex = 2;
            lblNombreCli.Text = "Nombre:";
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(148, 53);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(100, 23);
            txtTelefono.TabIndex = 1;
            txtTelefono.TextChanged += txtFonoCliente_TextChanged;
            // 
            // grpTamanioMasa
            // 
            grpTamanioMasa.Controls.Add(label2);
            grpTamanioMasa.Controls.Add(label1);
            grpTamanioMasa.Controls.Add(cboMasa);
            grpTamanioMasa.Controls.Add(cboTamano);
            grpTamanioMasa.Location = new Point(35, 134);
            grpTamanioMasa.Name = "grpTamanioMasa";
            grpTamanioMasa.Size = new Size(278, 114);
            grpTamanioMasa.TabIndex = 2;
            grpTamanioMasa.TabStop = false;
            grpTamanioMasa.Text = "Tamaño y Masa";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(51, 67);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 3;
            label2.Text = "Masa:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(51, 38);
            label1.Name = "label1";
            label1.Size = new Size(49, 15);
            label1.TabIndex = 2;
            label1.Text = "Tamaño";
            label1.Click += label1_Click;
            // 
            // cboMasa
            // 
            cboMasa.FormattingEnabled = true;
            cboMasa.Location = new Point(127, 64);
            cboMasa.Name = "cboMasa";
            cboMasa.Size = new Size(121, 23);
            cboMasa.TabIndex = 1;
            // 
            // cboTamano
            // 
            cboTamano.FormattingEnabled = true;
            cboTamano.Location = new Point(127, 35);
            cboTamano.Name = "cboTamano";
            cboTamano.Size = new Size(121, 23);
            cboTamano.TabIndex = 0;
            cboTamano.SelectedIndexChanged += cmbTamanio_SelectedIndexChanged;
            // 
            // grpAdicionales
            // 
            grpAdicionales.Controls.Add(chkTocino);
            grpAdicionales.Controls.Add(chkAceitunas);
            grpAdicionales.Controls.Add(chkChampinones);
            grpAdicionales.Controls.Add(chkPepperoni);
            grpAdicionales.Controls.Add(chkQuesoExtra);
            grpAdicionales.Location = new Point(354, 12);
            grpAdicionales.Name = "grpAdicionales";
            grpAdicionales.Size = new Size(157, 165);
            grpAdicionales.TabIndex = 3;
            grpAdicionales.TabStop = false;
            grpAdicionales.Text = "Adicionales";
            // 
            // chkTocino
            // 
            chkTocino.AutoSize = true;
            chkTocino.Location = new Point(16, 124);
            chkTocino.Name = "chkTocino";
            chkTocino.Size = new Size(61, 19);
            chkTocino.TabIndex = 4;
            chkTocino.Text = "Tocino";
            chkTocino.UseVisualStyleBackColor = true;
            // 
            // chkAceitunas
            // 
            chkAceitunas.AutoSize = true;
            chkAceitunas.Location = new Point(16, 97);
            chkAceitunas.Name = "chkAceitunas";
            chkAceitunas.Size = new Size(78, 19);
            chkAceitunas.TabIndex = 3;
            chkAceitunas.Text = "Aceitunas";
            chkAceitunas.UseVisualStyleBackColor = true;
            // 
            // chkChampinones
            // 
            chkChampinones.AutoSize = true;
            chkChampinones.Location = new Point(16, 72);
            chkChampinones.Name = "chkChampinones";
            chkChampinones.Size = new Size(100, 19);
            chkChampinones.TabIndex = 2;
            chkChampinones.Text = "Champiñones";
            chkChampinones.UseVisualStyleBackColor = true;
            // 
            // chkPepperoni
            // 
            chkPepperoni.AutoSize = true;
            chkPepperoni.Location = new Point(16, 47);
            chkPepperoni.Name = "chkPepperoni";
            chkPepperoni.Size = new Size(73, 19);
            chkPepperoni.TabIndex = 1;
            chkPepperoni.Text = "Peperoni";
            chkPepperoni.UseVisualStyleBackColor = true;
            // 
            // chkQuesoExtra
            // 
            chkQuesoExtra.AutoSize = true;
            chkQuesoExtra.Location = new Point(16, 22);
            chkQuesoExtra.Name = "chkQuesoExtra";
            chkQuesoExtra.Size = new Size(89, 19);
            chkQuesoExtra.TabIndex = 0;
            chkQuesoExtra.Text = "Quezo Extra";
            chkQuesoExtra.UseVisualStyleBackColor = true;
            // 
            // grpServicioDesc
            // 
            grpServicioDesc.Controls.Add(chkConvenioEstudiante);
            grpServicioDesc.Controls.Add(rdbDelivery);
            grpServicioDesc.Controls.Add(rdbRetiro);
            grpServicioDesc.Location = new Point(354, 183);
            grpServicioDesc.Name = "grpServicioDesc";
            grpServicioDesc.Size = new Size(291, 91);
            grpServicioDesc.TabIndex = 4;
            grpServicioDesc.TabStop = false;
            grpServicioDesc.Text = "Servicio y Descuento";
            // 
            // chkConvenioEstudiante
            // 
            chkConvenioEstudiante.AutoSize = true;
            chkConvenioEstudiante.Location = new Point(19, 47);
            chkConvenioEstudiante.Name = "chkConvenioEstudiante";
            chkConvenioEstudiante.Size = new Size(254, 19);
            chkConvenioEstudiante.TabIndex = 2;
            chkConvenioEstudiante.Text = "Convenio Estudiante IPVG (10% descuento)";
            chkConvenioEstudiante.UseVisualStyleBackColor = true;
            // 
            // rdbDelivery
            // 
            rdbDelivery.AutoSize = true;
            rdbDelivery.Location = new Point(139, 22);
            rdbDelivery.Name = "rdbDelivery";
            rdbDelivery.Size = new Size(67, 19);
            rdbDelivery.TabIndex = 1;
            rdbDelivery.TabStop = true;
            rdbDelivery.Text = "Delivery";
            rdbDelivery.UseVisualStyleBackColor = true;
            // 
            // rdbRetiro
            // 
            rdbRetiro.AutoSize = true;
            rdbRetiro.Location = new Point(19, 22);
            rdbRetiro.Name = "rdbRetiro";
            rdbRetiro.Size = new Size(103, 19);
            rdbRetiro.TabIndex = 0;
            rdbRetiro.TabStop = true;
            rdbRetiro.Text = "Retiro en Local";
            rdbRetiro.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblTotalValor);
            groupBox1.Controls.Add(lblIvaValor);
            groupBox1.Controls.Add(lblDeliveryValor);
            groupBox1.Controls.Add(lblDescuentoValor);
            groupBox1.Controls.Add(lblSubtotalValor);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Location = new Point(35, 269);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(343, 169);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Detalle de Pago";
            // 
            // lblTotalValor
            // 
            lblTotalValor.AutoSize = true;
            lblTotalValor.Location = new Point(252, 135);
            lblTotalValor.Name = "lblTotalValor";
            lblTotalValor.Size = new Size(43, 15);
            lblTotalValor.TabIndex = 9;
            lblTotalValor.Text = "$0 CLP";
            // 
            // lblIvaValor
            // 
            lblIvaValor.AutoSize = true;
            lblIvaValor.Location = new Point(252, 109);
            lblIvaValor.Name = "lblIvaValor";
            lblIvaValor.Size = new Size(43, 15);
            lblIvaValor.TabIndex = 8;
            lblIvaValor.Text = "$0 CLP";
            // 
            // lblDeliveryValor
            // 
            lblDeliveryValor.AutoSize = true;
            lblDeliveryValor.Location = new Point(252, 79);
            lblDeliveryValor.Name = "lblDeliveryValor";
            lblDeliveryValor.Size = new Size(43, 15);
            lblDeliveryValor.TabIndex = 7;
            lblDeliveryValor.Text = "$0 CLP";
            // 
            // lblDescuentoValor
            // 
            lblDescuentoValor.AutoSize = true;
            lblDescuentoValor.Location = new Point(252, 47);
            lblDescuentoValor.Name = "lblDescuentoValor";
            lblDescuentoValor.Size = new Size(43, 15);
            lblDescuentoValor.TabIndex = 6;
            lblDescuentoValor.Text = "$0 CLP";
            // 
            // lblSubtotalValor
            // 
            lblSubtotalValor.AutoSize = true;
            lblSubtotalValor.Location = new Point(252, 20);
            lblSubtotalValor.Name = "lblSubtotalValor";
            lblSubtotalValor.Size = new Size(43, 15);
            lblSubtotalValor.TabIndex = 5;
            lblSubtotalValor.Text = "$0 CLP";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(28, 135);
            label7.Name = "label7";
            label7.Size = new Size(93, 15);
            label7.TabIndex = 4;
            label7.Text = "TOTAL A PAGAR:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(28, 109);
            label6.Name = "label6";
            label6.Size = new Size(99, 15);
            label6.TabIndex = 3;
            label6.Text = "IVA chileno (19%)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(23, 79);
            label5.Name = "label5";
            label5.Size = new Size(98, 15);
            label5.TabIndex = 2;
            label5.Text = "Recargo Delivery:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(25, 47);
            label4.Name = "label4";
            label4.Size = new Size(96, 15);
            label4.TabIndex = 1;
            label4.Text = "Descuento(10%):";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 19);
            label3.Name = "label3";
            label3.Size = new Size(84, 15);
            label3.TabIndex = 0;
            label3.Text = "SubTotal Pizza:";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(440, 289);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(120, 30);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calculo Total";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(440, 325);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(120, 30);
            btnLimpiar.TabIndex = 7;
            btnLimpiar.Text = "Nuevo Pedido";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click_1;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(440, 363);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(120, 30);
            btnSalir.TabIndex = 8;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(656, 454);
            Controls.Add(btnSalir);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcular);
            Controls.Add(groupBox1);
            Controls.Add(grpServicioDesc);
            Controls.Add(grpAdicionales);
            Controls.Add(grpTamanioMasa);
            Controls.Add(grpDatosCliente);
            Name = "Form1";
            Load += Form1_Load;
            grpDatosCliente.ResumeLayout(false);
            grpDatosCliente.PerformLayout();
            grpTamanioMasa.ResumeLayout(false);
            grpTamanioMasa.PerformLayout();
            grpAdicionales.ResumeLayout(false);
            grpAdicionales.PerformLayout();
            grpServicioDesc.ResumeLayout(false);
            grpServicioDesc.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox txtCliente;
        private GroupBox grpDatosCliente;
        private Label lblFonoCli;
        private Label lblNombreCli;
        private TextBox txtTelefono;
        private GroupBox grpTamanioMasa;
        private ComboBox cboMasa;
        private ComboBox cboTamano;
        private GroupBox grpAdicionales;
        private CheckBox chkPepperoni;
        private CheckBox chkQuesoExtra;
        private GroupBox grpServicioDesc;
        private RadioButton rdbRetiro;
        private CheckBox chkConvenioEstudiante;
        private RadioButton rdbDelivery;
        private CheckBox chkAceitunas;
        private CheckBox chkChampinones;
        private Label label1;
        private CheckBox chkTocino;
        private GroupBox groupBox1;
        private Label label2;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label lblTotalValor;
        private Label lblIvaValor;
        private Label lblDeliveryValor;
        private Label lblDescuentoValor;
        private Label lblSubtotalValor;
        private Label label7;
        private Label label6;
        private Button btnCalcular;
        private Button btnLimpiar;
        private Button btnSalir;
    }
}
